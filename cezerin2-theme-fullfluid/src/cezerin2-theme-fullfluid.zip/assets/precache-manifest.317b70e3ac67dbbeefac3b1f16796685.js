self.__precacheManifest = [
  {
    "url": "/assets/js/app-0e2d578fd158ac963122.js"
  },
  {
    "revision": "445ea16dff8542bfbd1f",
    "url": "/assets/css/bundle-0d5ac4500f4cafc543cb.css"
  },
  {
    "url": "/assets/js/theme-445ea16dff8542bfbd1f.js"
  }
];