self.__precacheManifest = [
  {
    "url": "/assets/js/app-ca39ff6e9f985f661af2.js"
  },
  {
    "revision": "d891450612714faaf044",
    "url": "/assets/css/bundle-eed71ad86e4f53cc074d.css"
  },
  {
    "url": "/assets/js/theme-d891450612714faaf044.js"
  }
];