self.__precacheManifest = [
  {
    "url": "/assets/js/app-ca39ff6e9f985f661af2.js"
  },
  {
    "revision": "59de7a246edd494e249a",
    "url": "/assets/css/bundle-3675781e823c23df8010.css"
  },
  {
    "url": "/assets/js/theme-59de7a246edd494e249a.js"
  }
];