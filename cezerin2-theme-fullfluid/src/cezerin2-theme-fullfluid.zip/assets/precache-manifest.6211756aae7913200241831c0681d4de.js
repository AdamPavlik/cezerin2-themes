self.__precacheManifest = [
  {
    "url": "/assets/js/app-ca39ff6e9f985f661af2.js"
  },
  {
    "revision": "7f54c452dbb2760b6ac6",
    "url": "/assets/css/bundle-e636951e33c9b56f34bf.css"
  },
  {
    "url": "/assets/js/theme-7f54c452dbb2760b6ac6.js"
  }
];