self.__precacheManifest = [
  {
    "url": "/assets/js/app-ca39ff6e9f985f661af2.js"
  },
  {
    "revision": "84a094713a2f3652c00f",
    "url": "/assets/css/bundle-e264e64d48beab55f3e4.css"
  },
  {
    "url": "/assets/js/theme-84a094713a2f3652c00f.js"
  }
];