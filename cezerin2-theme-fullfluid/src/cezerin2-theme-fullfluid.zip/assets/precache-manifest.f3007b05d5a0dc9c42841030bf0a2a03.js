self.__precacheManifest = [
  {
    "url": "/assets/js/app-ca39ff6e9f985f661af2.js"
  },
  {
    "revision": "cbd782b47dcf385634a6",
    "url": "/assets/css/bundle-524e978da46eaae92f43.css"
  },
  {
    "url": "/assets/js/theme-cbd782b47dcf385634a6.js"
  }
];